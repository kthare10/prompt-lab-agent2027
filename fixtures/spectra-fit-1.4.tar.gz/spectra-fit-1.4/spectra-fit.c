/* spectra-fit 1.4 — fit a smoothed baseline to a 1-D spectrum.
 *
 * Deliberately old-fashioned: one translation unit, a hand-rolled argument
 * loop, and a hard dependency on both GSL and FFTW3 so the container
 * definition has to install real build dependencies rather than pretend.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gsl/gsl_statistics_double.h>
#include <fftw3.h>

#define MAX_POINTS 65536

static int read_dat(const char *path, double *x, int max) {
    FILE *fh = fopen(path, "r");
    int n = 0;
    if (!fh) { fprintf(stderr, "spectra-fit: cannot open %s\n", path); return -1; }
    while (n < max && fscanf(fh, "%lf", &x[n]) == 1) n++;
    fclose(fh);
    return n;
}

int main(int argc, char **argv) {
    const char *in = NULL, *out = NULL;
    static double x[MAX_POINTS];

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--input") && i + 1 < argc) in = argv[++i];
        else if (!strcmp(argv[i], "--output") && i + 1 < argc) out = argv[++i];
        else if (!strcmp(argv[i], "--version")) { printf("spectra-fit 1.4\n"); return 0; }
        else { fprintf(stderr, "usage: spectra-fit --input FILE.dat --output FILE.fit\n"); return 2; }
    }
    if (!in || !out) { fprintf(stderr, "usage: spectra-fit --input FILE.dat --output FILE.fit\n"); return 2; }

    int n = read_dat(in, x, MAX_POINTS);
    if (n <= 0) return 1;

    double mean = gsl_stats_mean(x, 1, n);
    double sd   = gsl_stats_sd_m(x, 1, n, mean);

    /* One real FFT, so libfftw3 is genuinely linked and not just declared. */
    fftw_complex *spec = fftw_malloc(sizeof(fftw_complex) * (n / 2 + 1));
    fftw_plan plan = fftw_plan_dft_r2c_1d(n, x, spec, FFTW_ESTIMATE);
    fftw_execute(plan);
    double power = 0.0;
    for (int k = 1; k < n / 2 + 1; k++)
        power += spec[k][0] * spec[k][0] + spec[k][1] * spec[k][1];
    fftw_destroy_plan(plan);
    fftw_free(spec);

    FILE *fo = fopen(out, "w");
    if (!fo) { fprintf(stderr, "spectra-fit: cannot write %s\n", out); return 1; }
    fprintf(fo, "# spectra-fit 1.4\npoints\t%d\nmean\t%.6f\nstddev\t%.6f\npower\t%.6f\n",
            n, mean, sd, power / (double) n);
    fclose(fo);
    fprintf(stderr, "spectra-fit: wrote %s (%d points)\n", out, n);
    return 0;
}
